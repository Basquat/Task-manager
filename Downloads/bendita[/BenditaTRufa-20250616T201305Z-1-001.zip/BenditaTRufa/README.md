# Bendita Trufa - Website

Este é um projeto de website para a loja de trufas artesanais "Bendita Trufa". O projeto inclui apenas o frontend, com uma estrutura básica para o backend.

## Estrutura do Projeto

```
src/
├── frontend/
│   ├── pages/           # Páginas HTML
│   │   ├── index.html   # Página inicial
│   │   ├── produtos.html # Página de produtos
│   │   ├── sobre.html   # Página sobre nós
│   │   └── contato.html # Página de contato
│   ├── css/             # Arquivos CSS
│   │   └── styles.css   # Estilos do site
│   ├── js/              # Arquivos JavaScript
│   │   └── main.js      # Script principal
│   └── img/             # Imagens do site
└── backend/             # Estrutura básica para o backend
    ├── controllers/     # Controladores
    ├── models/          # Modelos
    └── routes/          # Rotas
```

## Páginas do Site

1. **Home (index.html)**: Página inicial com apresentação da loja e produtos em destaque.
2. **Produtos (produtos.html)**: Catálogo completo de produtos, organizados por categorias.
3. **Sobre Nós (sobre.html)**: Informações sobre a história da empresa, missão, valores e equipe.
4. **Contato (contato.html)**: Formulário de contato e informações para contato direto.

## Funcionalidades Implementadas

- Design responsivo para diferentes tamanhos de tela
- Menu de navegação com suporte a dispositivos móveis
- Exibição de produtos em cards com efeitos de hover
- Formulário de contato com validação básica
- Seções para exibição de informações sobre a empresa e equipe

## Tecnologias Utilizadas

- HTML5
- CSS3 (Grid Layout, Flexbox, Media Queries)
- JavaScript (Vanilla JS)

## Como Usar

1. Clone este repositório
2. Abra o arquivo `src/frontend/pages/index.html` em seu navegador para visualizar o site

## Desenvolvimento Futuro

Para implementar o backend, você pode:

1. Escolher uma tecnologia de backend (Node.js, PHP, etc.)
2. Implementar os controladores, modelos e rotas na estrutura já criada
3. Conectar o frontend ao backend através de APIs

## Observações

Este projeto foi criado apenas para fins de demonstração. As imagens referenciadas no código HTML não estão incluídas no repositório e precisarão ser adicionadas na pasta `src/frontend/img/` para uma visualização completa do site.